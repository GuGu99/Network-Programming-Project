﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Net;

namespace Server
{
    public partial class Form2 : Form
    {
        private readonly int port;
        private TcpClient client;
        private TcpListener server;
        private NetworkStream mainstream;

        private readonly Thread Listening;
        private readonly Thread GetImage;

        public Form2(int Port)
        {
            try
            {
                port = Port;
                client = new TcpClient();
                Listening = new Thread(StartListening);
                GetImage = new Thread(ReceiveImage);
                InitializeComponent();
            }catch(Exception x)
            {
                MessageBox.Show(x.Message);
            }
        }

        //Listen for incomeing signals on the selected port
        private void StartListening()
        {
            try
            {
                while (!client.Connected) // 원격 리소스에 연결되있지 않다면
                {
                    server.Start();
                    client = server.AcceptTcpClient();
                }
                GetImage.Start();
            }catch(Exception x)
            {
                MessageBox.Show(x.Message);
            }
        }

        //Stop listening for incomeing signals on the selected port
        private void StopListening()
        {
            server.Stop();
            client = null;

            // 스레드가 살아있을시 종료
            if (Listening.IsAlive) Listening.Abort();
            if (GetImage.IsAlive) GetImage.Abort();
        }

        //Receve the data from the Client Computer
        private void ReceiveImage()
        {
            BinaryFormatter binformatter = new BinaryFormatter();
            while (client.Connected)
            {
                try
                {
                    mainstream = client.GetStream();
                    pictureBox1.Image = (Image)binformatter.Deserialize(mainstream);

                    if (!client.Connected)
                    {
                        MessageBox.Show("연결 완료!");
                        this.Close();
                    }
                }catch(Exception x)
                {
                    MessageBox.Show(x.Message + ". ");
                }
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            server = new TcpListener(IPAddress.Any, port);
            Listening.Start();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            StopListening();
        }

        private void stopListeningToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StopListening();
            MessageBox.Show("연결이 끊어짐. 프로그램을 종료합니다.");
            Application.Exit();
        }
    }
}
